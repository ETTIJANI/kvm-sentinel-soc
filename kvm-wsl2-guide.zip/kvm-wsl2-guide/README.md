# Déployer KVM sur Windows avec WSL2

Guide pratique : KVM / QEMU / libvirt dans WSL2 (virtualisation imbriquée).
Chaque bloc de code a un bouton de copie sur GitHub (coin supérieur droit du bloc).

> **Prérequis :** Windows 11, virtualisation activée dans le BIOS/UEFI (VT-x ou AMD-V), droits administrateur.
> Sur **Windows 10**, WSL2 et Docker fonctionnent, mais le nested KVM n'est pas pris en charge : `/dev/kvm` n'apparaît pas.

## Installation

### Étape 1 : WSL2 et Ubuntu (PowerShell, administrateur)

```powershell
wsl --install -d Ubuntu-24.04
wsl --update
wsl -l -v
```

Attendu : Ubuntu avec VERSION = 2.

### Étape 2 : nested KVM et systemd

PowerShell (crée `.wslconfig` ; s'il existe déjà, l'éditer avec notepad) :

```powershell
$cfg = "[wsl2]","nestedVirtualization=true"
Set-Content -Path "$env:UserProfile\.wslconfig" -Value $cfg
```

Ubuntu :

```bash
printf '[boot]\nsystemd=true\n' | sudo tee /etc/wsl.conf
```

PowerShell, puis attendre environ 8 secondes et rouvrir Ubuntu :

```powershell
wsl --shutdown
```

Ubuntu (attendu : `systemd`) :

```bash
cat /proc/1/comm
```

### Étape 3 : paquets (Ubuntu)

```bash
sudo apt update
sudo apt install -y qemu-kvm libvirt-daemon-system libvirt-clients bridge-utils cpu-checker virtinst
```

### Étape 4 : groupes, service, réseau (Ubuntu)

```bash
sudo usermod -aG libvirt,kvm $USER
sudo systemctl enable --now libvirtd
sudo virsh net-start default || true
sudo virsh net-autostart default
```

PowerShell, puis rouvrir Ubuntu :

```powershell
wsl --shutdown
```

### Étape 5 : validation (Ubuntu)

```bash
ls -l /dev/kvm
kvm-ok
systemctl is-active libvirtd
virsh -c qemu:///system list --all
virsh -c qemu:///system net-list --all
```

Attendu : `/dev/kvm` existe ; « KVM acceleration can be used » ; `active` ; liste vide sans erreur ; réseau `default` actif et en démarrage automatique.

## Erreurs d'installation et de téléchargement

| Symptôme | Solution |
|---|---|
| `wsl--install-d` : « not recognized » | Espaces manquants : `wsl --install -d Ubuntu-24.04`. Appuyer sur Échap pour vider la ligne avant de coller. |
| `Invalid distribution name` | WSL ancien ou nom inconnu : `wsl --update`, puis `wsl --list --online`, installer avec le nom affiché. |
| `wsl --install` sans effet | Windows trop ancien : build 19041 ou plus requis (`winver`). |
| Erreur `0x80370102` | Activer VT-x/AMD-V dans le BIOS, activer les fonctionnalités Windows ci-dessous, redémarrer. |
| Téléchargement bloqué ou en échec | Utiliser `--web-download` ; vérifier connexion et proxy. |
| Accès refusé | Ouvrir PowerShell en administrateur. |
| Tiret long (`wsl –version`) | Utiliser deux tirets simples `--` ; copier depuis ce dépôt. |

PowerShell, administrateur :

```powershell
winver
wsl --update
wsl --list --online
wsl --install -d Ubuntu
wsl --install --web-download -d Ubuntu
```

PowerShell, administrateur, puis redémarrer :

```powershell
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
```

## Erreurs après installation

| Symptôme | Solution |
|---|---|
| `/dev/kvm` absent | Vérifier `.wslconfig`, puis `wsl --update` et `wsl --shutdown`. Contrôler le BIOS. Windows 10 : non pris en charge. |
| `kvm-ok` positif mais `nested` = N | Ignorer le paramètre ; se fier à `kvm-ok` et `/dev/kvm`. |
| `nestedVirtualization` ignoré | Stratégie « Allow nested virtualization » désactivée sur un PC géré, ou Windows 10. |
| systemd non actif après modification | `wsl --shutdown`, attendre 8 secondes, rouvrir Ubuntu. |
| Erreur udev à l'installation | `sudo dpkg --configure -a` puis `sudo apt -f install`. |
| `Permission denied` | Refaire `usermod` (étape 4), `wsl --shutdown`, vérifier avec `id`. |

## Liste de contrôle

- [ ] Windows 11, virtualisation activée
- [ ] Ubuntu en VERSION 2
- [ ] `.wslconfig` et `/etc/wsl.conf` configurés
- [ ] `cat /proc/1/comm` affiche `systemd`
- [ ] `/dev/kvm` existe, `kvm-ok` positif
- [ ] `virsh -c qemu:///system list --all` sans erreur
- [ ] Réseau `default` actif et en démarrage automatique

## Fichiers

- `kvm_wsl2.tex` : version PDF du guide (LaTeX, à compiler avec pdflatex).
- `commandes.txt` : toutes les commandes dans l'ordre d'exécution.
- `guide_kvm_wsl2.html` : version hors ligne avec boutons « Copier ».
